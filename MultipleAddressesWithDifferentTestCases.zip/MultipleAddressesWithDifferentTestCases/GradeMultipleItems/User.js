var FileName="";
var TestCase="";
var CurrentRow="";
var counter=0;


function setGlobalData(/**string*/ filename,/**string*/ testcase)
{
   FileName=filename;
   TestCase=testcase;
}


function data(/**string*/ SheetName)
{
   var success = Spreadsheet.DoAttach(FileName,SheetName);
   Tester.Assert('Open Spreadsheet', success);
   
   var rowCount = Spreadsheet.GetRowCount();
   var columnCount = Spreadsheet.GetColumnCount();
   counter=0;
   
   for(i=1;i<=rowCount;i++)
   {
        if(Spreadsheet.GetCell(0,i) == TestCase)
		{
		    counter=counter+1;
		    if(counter==1)
		    {
		      CurrentRow=i;
		    }
		    
		}
		else
		{ 
		  continue;
		}
   }
 }


function Login ()
{
   data('Login');
   
   SeS('username').DoClick();
   SeS('username').DoSetText(Spreadsheet.GetCell('Username',CurrentRow));
   SeS('password').DoClick();
   SeS('password').DoSetText(Spreadsheet.GetCell('Password',CurrentRow));
   SeS('Sign_In').DoClick();
   Tester.Message('Counter is'+counter);
  
}

function CreateNewEntity()
{
   SeS('Entities').DoClick();
   Navigator.ExecJS('return arguments[0].click();',SeS('Create'));
}


function AddAddressDetails()
{
     
     data('EntityInformation');
     var lastRow=(CurrentRow+counter)-1;
     
     for(addressDetails=CurrentRow;addressDetails<=lastRow;addressDetails++)
     {
       var addressNum= parseInt(Spreadsheet.GetCell('AddressNumber',addressDetails))-1;  
       SeS('AddAddress').DoClick();
       Global.DoWaitFor('Address',2500,500);
       
       //State
       var AddressState = SeS('State',{AddressNumber:addressNum});
       SelectDropdown(AddressState,Spreadsheet.GetCell('State',addressDetails));
       
       //City
       SeS('City',{AddressNumber:addressNum}).DoClick();
       SeS('City',{AddressNumber:addressNum}).DoSetText(Spreadsheet.GetCell('City',addressDetails));
       
       //ZipCode
       SeS('PostalCode',{AddressNumber:addressNum}).DoClick();
       SeS('PostalCode',{AddressNumber:addressNum}).DoSetText(Spreadsheet.GetCell('ZipCode',addressDetails));
       
       //Address
       SeS('Address',{AddressNumber:addressNum}).DoClick();
       SeS('Address',{AddressNumber:addressNum}).DoSetText(Spreadsheet.GetCell('Address',addressDetails));
       
       //Submit
   //  SeS('AddressSubmit').DoClick();
   //  waitForPageLoad();
      
    
       SeS('CustomerAddressDone',{AddressNumber:addressNum}).DoClick();
       
     }

  
}

function Logout()
{

  SeS('ProfileLink').DoClick();
  SeS('LogoutLink').DoClick();

}

function SelectDropdown(/**string*/ locator,/**string*/ itemText)
{
   locator.DoClick();
   var objId = locator._DoDOMGetAttribute("id");
   objId=objId.replace("_label","");
   
   if(objId)
   {
   Navigator.ExecJS('return arguments[0].click();',Navigator.Find('//ul[@id="'+objId+'_items"]//li[@data-label="'+itemText+'"]'));
   }
   else
   {
     Tester.Assert('Error selecting option', false)
   }

}

function waitForPageLoad()
{
  var waitTotal=0;
  var loader = SeSFindObj('PageLoad');
  var display=false;
  
  do
  {
    if(SeSFindObj('PageLoad'))
    {
      display=false;
      Global.DoSleep(3000)
      waitTotal=waitTotal+3000;
    }
    else
    {
      display=true;
    }
  }
  while(display!=true);



}
	
