var FileName="";
var SheetName="";
var CurrentRow="";
var counter=0;


function setGlobalData(/**string*/ filename,/**string*/ sheetname)
{
   FileName=filename;
   SheetName=sheetname;
   data();
}



function data()
{
   var success = Spreadsheet.DoAttach(FileName,SheetName);
   Tester.Assert('Open Spreadsheet', success);
   
   var rowCount = Spreadsheet.GetRowCount();
   var columnCount = Spreadsheet.GetColumnCount();
   counter=0;
   
   for(i=1;i<=rowCount;i++)
   {
        if(Spreadsheet.GetCell(0,i) == Global.GetProperty('TestCase'))
		{
		    counter=counter+1;
		    if(counter==1)
		    {
		      CurrentRow=i;
		    }
		    
		}
		else
		{ 
		  continue;
		}
   }
 }


function Login ()
{
  Navigator.Open(Global.GetProperty('baseUrl'));
  Navigator.Maximize();
  SeS('username').DoClick();
  SeS('username').DoSetText(Spreadsheet.GetCell('Username',CurrentRow));
  SeS('password').DoClick();
  SeS('password').DoSetText(Spreadsheet.GetCell('Password',CurrentRow));
  SeS('Sign_In').DoClick();
  Global.DoSleep(1000)
  
  if(SeSFindObj('MultipleSessionsDetected.'))
  {
    Navigator.ExecJS('return arguments[0].click();',SeS('ContinueSession')); 
  }
  
}

function CreateNewQuote()
{
   Global.SetProperty('CreateModule',"Quote");
   Global.DoSleep(5000);
   SeS('Quotes').DoClick();
   Global.DoWaitFor('QuoteSearchResults',2000);
   Navigator.ExecJS('return arguments[0].click();',SeS('Create'));
   Global.SetProperty('QuoteStatus',"Quote Not Saved");
   Global.SetProperty('QuoteNumber',"");
}

function SelectQuoteProgram()
{

   if(Spreadsheet.GetCell('QuoteProgramExecution',CurrentRow)!=="N")
  {
   //ProgramSearch
   Global.DoWaitFor('ProgramSearch',1000);
   SeS('ProgramSearch').DoClick();
   Global.DoWaitFor('FilterByProgramName',1000);
   SeS('Advanced_Search').DoClick();
   Global.DoWaitFor('ProgramNameAdvancedSearch',300);
   SeS('ProgramNameAdvancedSearch').DoClick();
   SeS('ProgramNameAdvancedSearch').DoSetText(Spreadsheet.GetCell('ProgramName',CurrentRow));
   SeS('AdvancedSearchButton').DoClick();
   SeS('Select').DoClick();
  }
   
   
}

function QuoteCustomer()
{
  if(Spreadsheet.GetCell('QuoteCustomerExecution',CurrentRow)!=="N")
  {


  if(Spreadsheet.GetCell('CustomerAction',CurrentRow)=="SelectCustomer")
  {
    //Customer Search
   Global.DoWaitFor('CustomerSearch',1000);
   SeS('CustomerSearch').DoClick();
   Global.DoWaitFor('Filter_by_Customer_Name',300);
   SeS('Advanced_Search').DoClick();
   Global.DoWaitFor('CustomerNumberAdvancedSearch',300);
   SeS('CustomerNumberAdvancedSearch').DoClick();
   SeS('CustomerNumberAdvancedSearch').DoSetText(Spreadsheet.GetCell('CustomerNumber',CurrentRow));
   SeS('AdvancedSearchButton').DoClick();
   SeS('Select').DoClick();
  }
  else if(Spreadsheet.GetCell('CustomerAction',CurrentRow)=="CreateCustomer")
  {
     CreateNewEntity();
  }
  }
}

function PreliminaryQuoteDetails()
{
  if(Spreadsheet.GetCell('QuotePreliminaryDataExecution',CurrentRow)!=="N")
  {
   //Financial Product
   var FinanceProduct = SeS('FinanceProductType');
   SelectDropdown(FinanceProduct,Spreadsheet.GetCell('FinancialProductType',CurrentRow));
   
   //Term
   Navigator.ExecJS('return arguments[0].focus();',SeS('Term'));
   SeS('Term').DoClick();
   Global.DoSleep(300)
   SeS('Term').DoSetText(Spreadsheet.GetCell('Term',CurrentRow))
   Global.DoSleep(1000)
   
   //RequestedAmount
   Navigator.ExecJS('return arguments[0].focus();',SeS('RequestedAmount'));
   SeS('RequestedAmount').DoClick();
   SeS('RequestedAmount').DoSetText(Spreadsheet.GetCell('RequestedAmount',CurrentRow))
   Global.DoSleep(1000)
   
   }
}

function AddAssetDetails()
{
    
     if(Spreadsheet.GetCell('QuoteAssetExecution',CurrentRow)!=="N")
     {
     var lastRow=(CurrentRow+counter)-1;
     
     for(assetDetails=CurrentRow;assetDetails<=lastRow;assetDetails++)
     {
       if(Spreadsheet.GetCell('AssetNumber',assetDetails)!=="")
       {
       var assetNum= parseInt(Spreadsheet.GetCell('AssetNumber',assetDetails))-1;  
       SeS('CreateAsset').DoClick();
       waitForPageLoad();
       
       //AssetCategory
       var AssetCategory = SeS('AssetCategory',{AssetNumber:assetNum});
       SelectDropdown(AssetCategory,Spreadsheet.GetCell('AssetCategory',assetDetails));
       
       Global.DoSleep(1000);
       
       //AssetType
       var AssetType = SeS('AssetType',{AssetNumber:assetNum});
       SelectDropdown(AssetType,Spreadsheet.GetCell('AssetType',assetDetails));
       
       //Quantity
       SeS('Quantity',{AssetNumber:assetNum}).DoClick();
       SeS('Quantity',{AssetNumber:assetNum}).DoSetText("");
       SeS('Quantity',{AssetNumber:assetNum}).DoClick();
       SeS('Quantity',{AssetNumber:assetNum}).DoSetText(Spreadsheet.GetCell('AssetQuantity',assetDetails));
       waitForAjaxSpinner();
       
       //UnitCost
       SeS('UnitCost',{AssetNumber:assetNum}).DoClick();
       SeS('UnitCost',{AssetNumber:assetNum}).DoSetText(Spreadsheet.GetCell('UnitCost',assetDetails));
       
       //SearchVendor
       SeS('SearchAssetVendor',{AssetNumber:assetNum}).DoClick();
       
       Global.DoWaitFor('Advanced_Search',500,100);
       SeS('Advanced_Search').DoClick();
       Global.DoWaitFor('Vendor_Number',1000,500);
       SeS('Vendor_Number').DoSetText(Spreadsheet.GetCell('AssetVendor',assetDetails))
	   Global.DoSleep(200)
       SeS('AdvancedSearchButton').DoClick();
       
       Global.DoWaitFor('Select',1000,500);
       SeS('Select').DoClick();
       
       //AssetDone
       SeS('AssetDone',{AssetNumber:assetNum}).DoEnsureVisible();
       SeS('AssetDone',{AssetNumber:assetNum}).DoClick();
       }
       else
       {
         continue;
       }
     }
  }
  
}

function NavigateNextQuote()
{
   if(Spreadsheet.GetCell('NavigateNextExecution',CurrentRow)!=="N")
   {
   SeS('Next').DoClick();
   waitForPageLoad();
   
   if(SeSFindObj('ErrorMessages'))
   {
       checkErrorMessages();
   }
   
   if(SeSFindObj('QuoteStatus'))
   {
     Global.SetProperty('QuoteStatus',"New");
     Global.SetProperty('QuoteNumber',SeS('QuoteNumber').GetText());
   }
   else
   {
     Global.SetProperty('QuoteStatus',"Quote Not Saved");
     Global.SetProperty('QuoteNumber',"");
   }
    
 

   }
}

function SaveQuote()
{
   if(Spreadsheet.GetCell('SaveExecution',CurrentRow)!=="N")
   {
   SeS('SaveQuote').DoClick();
   waitForPageLoad();
   if(SeS('QuoteStatus').GetText()=='Saved')
   {
     Global.SetProperty('QuoteStatus',"Saved");
   }
   }
}


function QuotePricing()
{
   if(Spreadsheet.GetCell('PricingExecution',CurrentRow)!=="N")
   {
   if(Spreadsheet.GetCell('PriceQuote',CurrentRow)=="Y")
   {
   SeS('QuotePricing').DoClick();
   waitForPageLoad();
   
   if(SeS('QuotePricingOptionStatus').GetText()=='Priced')
   {
     Global.SetProperty('QuoteStatus',"Priced");
   }
   }
   else
   {
     Tester.Message('Quote not priced')
   }
  }
}

function AcceptQuote()
{
   if(Spreadsheet.GetCell('QuoteAcceptanceExecution',CurrentRow)!=="N")
   {
   if(Spreadsheet.GetCell('GenerateProposal',CurrentRow)=='Y')
   {
     SeS('GenerateProposal').DoClick();
     waitForPageLoad();
     if(SeS('QuoteStatus').GetText()=='Completed')
     {
     Global.SetProperty('QuoteStatus',"Generated Proposal");
     }
   }
   
   if(Spreadsheet.GetCell('AcceptQuote',CurrentRow)=='Y')
   {
       SeS('More').DoClick();
       SeS('Accept').DoClick();
       waitForPageLoad();
       
       Tester.AssertEqual(Global.SetProperty('QuoteStatus',"Quote Successfully Accepted"),Global.GetProperty('QuoteNumber'),SeS('ApplicationNumber').GetText());
       
   }
 }
 
}

function CreateNewApplication()
{
  SeS('ApplicationsTab').DoClick();
  Global.DoWaitFor('ApplicationSearchResults',800)
  
  Navigator.ExecJS('return arguments[0].click();',SeS('Create'));
  
  //ApplicationNature
  var ApplicationNature = SeS('ApplicationNature')
  SelectDropdown(ApplicationNature,Spreadsheet.GetCell('ApplicationNature',CurrentRow));
  Global.DoSleep(250);
  
  var ApplicationType = SeS('ApplicationType')
  SelectDropdown(ApplicationType,Spreadsheet.GetCell('ApplicationType',CurrentRow));
  
  if(Spreadsheet.GetCell('ApplicationNature',CurrentRow)=="Syndicated")
  {
    var PurchaseType = SeS('PurchaseType')
    SelectDropdown(PurchaseType,Spreadsheet.GetCell('PurchaseType',CurrentRow));
    Global.DoSleep(1500);
  }
  
   
   SeS('Next').DoClick();
   waitForPageLoad();
   
   Global.DoWaitFor('FilterByCustomerNumber',500);
    
 
}

function SelectApplicationCustomerProgram()
{
   SeS('Advanced_Search').DoClick();
   Global.DoWaitFor('CustomerNumberAdvancedSearch',150);
   SeS('CustomerNumberAdvancedSearch').DoClick();
   SeS('CustomerNumberAdvancedSearch').DoSetText(Spreadsheet.GetCell('CustomerNumber',CurrentRow));
   SeS('AdvancedSearchButton').DoClick();
   SeS('Select').DoClick();
   
   waitForPageLoad();
   
   Global.DoWaitFor('Advanced_Search',450);
   Navigator.ExecJS('return arguments[0].click();',SeS('Advanced_Search'));
   Global.DoWaitFor('ProgramNameAdvancedSearch',250);
   SeS('ProgramNameAdvancedSearch').DoClick();
   SeS('ProgramNameAdvancedSearch').DoSetText(Spreadsheet.GetCell('ProgramName',CurrentRow));
   SeS('AdvancedSearchButton').DoClick();
   SeS('Select').DoClick();
}

function ApplicationPreliminaryDetails()
{
  Global.DoWaitFor('ApplicationFinanceProductType',1000);
  var FinanceProduct = SeS('ApplicationFinanceProductType');
  SelectDropdown(FinanceProduct,Spreadsheet.GetCell('FinanceProductType',CurrentRow));
  
  Navigator.ExecJS('return arguments[0].focus();',SeS('ApplicationTerm'));
  SeS('ApplicationTerm').DoClick();
  SeS('ApplicationTerm').DoSetText(Spreadsheet.GetCell('Term',CurrentRow));
  waitForAjaxSpinner();
  
  Navigator.ExecJS('return arguments[0].focus();',SeS('ApplicationRequestedAmount'));
  SeS('ApplicationRequestedAmount').DoClick();
  SeS('ApplicationRequestedAmount').DoSetText(Spreadsheet.GetCell('RequestedAmount',CurrentRow));
  
  SeS('ApplicationDownPaymentAmount').DoClick();
  SeS('ApplicationDownPaymentAmount').DoSetText(Spreadsheet.GetCell('DownPaymentAmount',CurrentRow));
  
  SeS('ApplicationDownPaymentPercent').DoClick();
  SeS('ApplicationDownPaymentPercent').DoSetText(Spreadsheet.GetCell('DownPaymentPercent',CurrentRow));
  
}

function CreateApplicationAssets()
{
     var lastRow=(CurrentRow+counter)-1;
     
     for(assetDetails=CurrentRow;assetDetails<=lastRow;assetDetails++)
     {
       if(Spreadsheet.GetCell('AssetNumber',assetDetails)!=="")
       {
       var assetNum= parseInt(Spreadsheet.GetCell('AssetNumber',assetDetails))-1;  
       SeS('CreateApplicationAsset').DoClick();
       waitForPageLoad();
       
       //AssetCategory
       var AssetCategory = SeS('ApplicationAssetCategory',{AssetNumber:assetNum});
       SelectDropdown(AssetCategory,Spreadsheet.GetCell('AssetCategory',assetDetails));
       
       Global.DoSleep(1000);
       
       //AssetType
       var AssetType = SeS('ApplicationAssetType',{AssetNumber:assetNum});
       SelectDropdown(AssetType,Spreadsheet.GetCell('AssetType',assetDetails));
       
       //Quantity
       SeS('ApplicationAssetQuantity',{AssetNumber:assetNum}).DoClick();
       SeS('ApplicationAssetQuantity',{AssetNumber:assetNum}).DoSetText("");
       SeS('ApplicationAssetQuantity',{AssetNumber:assetNum}).DoClick();
       SeS('ApplicationAssetQuantity',{AssetNumber:assetNum}).DoSetText(Spreadsheet.GetCell('AssetQuantity',assetDetails));
       
       //UnitCost
       SeS('ApplicationAssetCost',{AssetNumber:assetNum}).DoClick();
       SeS('ApplicationAssetCost',{AssetNumber:assetNum}).DoSetText(Spreadsheet.GetCell('UnitCost',assetDetails));
       
       //SearchVendor
       
       SeS('ApplicationAssetVendor',{AssetNumber:assetNum}).DoClick();
       
       Global.DoWaitFor('Advanced_Search',500,100);
       SeS('Advanced_Search').DoClick();
       Global.DoWaitFor('Vendor_Number',1000,500);
       SeS('Vendor_Number').DoSetText(Spreadsheet.GetCell('AssetVendor',assetDetails))
	   Global.DoSleep(200)
       SeS('AdvancedSearchButton').DoClick();
       
       Global.DoWaitFor('Select',1000,500);
       SeS('Select').DoClick();
       
       //AssetDone
       SeS('ApplicationAssetDone',{AssetNumber:assetNum}).DoEnsureVisible();
       SeS('ApplicationAssetDone',{AssetNumber:assetNum}).DoClick();
       }
       else
       {
         continue;
       }
     }
}

function NavigateNext()
{
   SeS('NextNavigateApplication').DoClick();
   waitForPageLoad();
}

function SaveApplication()
{
   SeS('SaveApplication').DoClick(); 
   waitForPageLoad();
}

function SubmitApplication()
{
   SeS('SubmitApplication').DoClick();
   waitForPageLoad();
}

function ApplicationWorkFlow()
{
  var ApplicationStatus ="";
  
  do
  {
    Global.DoSleep(3500);
    ApplicationStatus = SeS('ApplicationStatus').GetText();
    Tester.Message('Application Status is'+ApplicationStatus)
    switch(ApplicationStatus)
    {
      
      case "Pending - Application Duplicate Verification":
      
      SeS('ApplicationReviewTab').DoClick();
      Global.DoWaitFor('DuplicateApplicationsTab',400);
      SeS('DuplicateApplicationsTab').DoClick();
      Navigator.ExecJS('return arguments[0].click();',SeS('VerificationOfDuplicates'));
      SeS('DuplicateApplicationComments').DoClick();
      SeS('DuplicateApplicationComments').DoSetText('Clear')  
      
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskHandlingIcon'));
      waitForAjaxSpinner();
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskSubHandlingIcon',{TaskSubAction:"Claim"}));
  
      waitForPageLoad();
      
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskHandlingIcon'));
      waitForAjaxSpinner();  
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskSubHandlingIcon',{TaskSubAction:"Complete"}));
      
      waitForPageLoad();
      break;
    
      case "Pending - Sales Review":
      
      SeS('TaskHandlingIcon').DoClick();
      waitForAjaxSpinner();
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskSubHandlingIcon',{TaskSubAction:"Claim"}));
      waitForPageLoad();
      Global.DoSleep(4000)
      SeS('TaskHandlingIcon').DoClick();
      waitForAjaxSpinner();
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskSubHandlingIcon',{TaskSubAction:"Submit to Credit"}));
      waitForPageLoad();
      Global.DoWaitFor('ConfirmTaskDialog',2500);
      SeS('ConfirmTaskDialog').DoClick();
      waitForPageLoad();
      break;
      
      case "Pending - Syndication":
      
      SeS('TaskHandlingIcon').DoClick();
      waitForAjaxSpinner();
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskSubHandlingIcon',{TaskSubAction:"Claim"}));
      waitForPageLoad();
      Global.DoSleep(4000)
      SeS('TaskHandlingIcon').DoClick();
      waitForAjaxSpinner();
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskSubHandlingIcon',{TaskSubAction:"Submit for Decision"}));
      waitForPageLoad();
      break;
      
      case "Pending - Credit Review":
      
      Navigator.ExecJS('return arguments[0].scrollIntoView();',SeS('SyndicationTab'))
      Navigator.ExecJS('return arguments[0].click();',SeS('SyndicationTab'))
      
      Global.DoWaitFor('SyndicatedStatus',2000);
      var SyndicatedStatusDropdown = SeS('SyndicatedStatus');
      SelectDropdown(SyndicatedStatusDropdown,'Approved Serviced');
      waitForAjaxSpinner();
      
 
      
      SeS('TaskHandlingIcon').DoClick();
      waitForAjaxSpinner();
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskSubHandlingIcon',{TaskSubAction:"Claim"}));
      waitForPageLoad();
      Global.DoSleep(4000)
      SeS('TaskHandlingIcon').DoClick();
      waitForAjaxSpinner();
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskSubHandlingIcon',{TaskSubAction:"Submit for Syndication"}));
      waitForPageLoad();
           
      Navigator.ExecJS('return arguments[0].scrollIntoView();',SeS('ApplicationTab'))
      Navigator.ExecJS('return arguments[0].click();',SeS('ApplicationTab'));
      
      
      break;
      
      case "Pending - AML Review":
      
      SeS('TaskHandlingIcon').DoClick();
      waitForAjaxSpinner();
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskSubHandlingIcon',{TaskSubAction:"Claim"}));
      waitForPageLoad();
      Global.DoSleep(4000)
      SeS('TaskHandlingIcon').DoClick();
      waitForAjaxSpinner();
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskSubHandlingIcon',{TaskSubAction:"Approve"}));
      waitForPageLoad();
      
      break;
      
      case "Pending - Compliance Review":
      
      SeS('CreditAnalysisTab').DoClick();
      SeS('ComplianceTab').DoClick();
      Global.DoWaitFor('ComplianceTable');
      var rows = SeS('ComplianceTable').DoDOMQueryXPath('./tr');
      
      for(rowCount=0;rowCount<rows.length;rowCount++)
      {
         
       if(SeSFindObj('ComplianceEdit',{ComplianceRow:rowCount}))
       {
         Navigator.ExecJS('return arguments[0].click();',SeS('ComplianceEdit',{ComplianceRow:rowCount}));
         waitForPageLoad();
         
         Navigator.ExecJS('return arguments[0].click();',SeS('OFACTab'));
         waitForAjaxSpinner();
         var OFACCompliance = SeS('OFACVerification').GetText();
         if(OFACCompliance!=="No Hit")
         {
           Navigator.ExecJS('return arguments[0].focus();',SeS('OFACVerification'));
           var OFACComp = SeS('OFACVerification');
           SelectDropdown(OFACComp,'Cleared Hit');
           waitForAjaxSpinner();
           Navigator.ExecJS('return arguments[0].click();',SeS('SubPageSave'));
           waitForPageLoad();
         }
         
         Navigator.ExecJS('return arguments[0].click();',SeS('PEPTab'));
         waitForAjaxSpinner();
         var PEPCompliance = SeS('PEPVerification').GetText();
         if(PEPCompliance!=="No Hit")
         {
           Navigator.ExecJS('return arguments[0].focus();',SeS('PEPVerification'));
           var PEPComp = SeS('PEPVerification')
           SelectDropdown(PEPComp,'Cleared Hit');
           waitForAjaxSpinner();
           Navigator.ExecJS('return arguments[0].click();',SeS('SubPageSave'));
           waitForPageLoad();
         }
         
          
         Navigator.ExecJS('return arguments[0].click();',SeS('BankruptcyTab'));
         waitForAjaxSpinner();
         var BankruptcyCompliance = SeS('BankruptcyVerification').GetText();
         if(BankruptcyCompliance!=="No Hit")
         {
           Navigator.ExecJS('return arguments[0].focus();',SeS('BankruptcyVerification'));
           var BankruptcyComp = SeS('BankruptcyVerification')
           SelectDropdown(BankruptcyComp,'Cleared Hit');
           waitForAjaxSpinner();
           Navigator.ExecJS('return arguments[0].click();',SeS('SubPageSave'));
           waitForPageLoad();
         }
         
         Navigator.ExecJS('return arguments[0].click();',SeS('NegativeNewsTab'));
         waitForAjaxSpinner();
         var NegativeNewsCompliance = SeS('NegativeNewsVerification').GetText();
         if(NegativeNewsCompliance!=="No Hit")
         {
           Navigator.ExecJS('return arguments[0].focus();',SeS('NegativeNewsVerification'));
           var NegativeNewsComp = SeS('NegativeNewsVerification')
           SelectDropdown(NegativeNewsComp,'Cleared Hit');
           waitForAjaxSpinner();
           Navigator.ExecJS('return arguments[0].click();',SeS('SubPageSave'));
           waitForPageLoad();
         }
         
         Navigator.ExecJS('return arguments[0].click();',SeS('SubPageDone'));
         waitForPageLoad();
         
       }
      
      }
      
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskHandlingIcon'));
      waitForAjaxSpinner();
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskSubHandlingIcon',{TaskSubAction:"Claim"}));
  
      waitForPageLoad();
      
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskHandlingIcon'));
      waitForAjaxSpinner();  
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskSubHandlingIcon',{TaskSubAction:"Complete"}));
      
      waitForPageLoad();
      Global.DoSleep(5000);
      
      Navigator.ExecJS('return arguments[0].click();',SeS('SaveEntityFlow'));
      waitForPageLoad();
      
      break;
      
      case "Pending - Credit Decision":
      
      SeS('TaskHandlingIcon').DoClick();
      waitForAjaxSpinner();
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskSubHandlingIcon',{TaskSubAction:"Claim"}));
      waitForPageLoad();
      Global.DoSleep(4000)
      SeS('TaskHandlingIcon').DoClick();
      waitForAjaxSpinner();
      Navigator.ExecJS('return arguments[0].click();',SeS('TaskSubHandlingIcon',{TaskSubAction:"Approve"}));
      waitForPageLoad();
      Global.DoWaitFor('ConfirmTaskDialog',2500);
      SeS('ConfirmTaskDialog').DoClick();
      waitForPageLoad();
      
      Global.DoSleep(2500)
      
      break;
      
      
      default:
      waitForPageLoad();
 
    
    
    }
    
  
  
  }while(ApplicationStatus!=="Approved - Accepted by Customer");


}

function checkErrorMessages()
{
  var jsonErrorMessage="";
  var expectedErrors = [];
  var actualErrors = [];
  
  
    errorCount=SeS('ErrorMessages').DoDOMChildrenCount();
    var errorlist=SeS('ErrorMessages').DoDOMQueryXPath('*');
    
    for(var i=0;i<errorlist.length;i++)
    {
      var error = errorlist[i];
      actualErrors.push(error.GetText())
    }
  
  
  
  if(Global.GetProperty('baseUrl').search('pb')!== -1)
  {
  jsonErrorMessage = PropertiesToJSON('QCPBErrors.properties','PBMACErrors.json');
  }
  else
  {
  jsonErrorMessage = PropertiesToJSON('errorMessages.properties','Errors.json');
  }
  
  for(var error in jsonErrorMessage) 
  {
  
      for(var actError=0;actError<actualErrors.length;actError++)
      {
        if (jsonErrorMessage.hasOwnProperty(error)) 
        {
          
         if(jsonErrorMessage[error]==actualErrors[actError])
         {
           Tester.Message('Error is'+actualErrors[actError])
           expectedErrors.push(jsonErrorMessage[error])
         }
          
        }
      
      }
      
   }
   
   actualErrors.sort();
   expectedErrors.sort();

   //Compare actual and expected error messages

  if(expectedErrors.length==actualErrors.length)
   {
     if(JSON.stringify(expectedErrors) === JSON.stringify(actualErrors))
     {
       Tester.Assert('Error messages displayed as expected',true)
     }
     else
     {
       Tester.Assert('Error messages not displayed as expected',false)
     }
   
   }
}

function Logout()
{

  SeS('ProfileLink').DoClick();
  SeS('LogoutLink').DoClick();

}

function QuoteExecutionResults()
{
  
  var RowCount = parseInt(SeS('QuoteExecutionResults').GetRowCount())-1;
  
  SeS('QuoteExecutionResults').SetCell(Global.GetProperty("TestCase"),"TestCase",parseInt(RowCount)+1);
  
  SeS('QuoteExecutionResults').SetCell(Global.GetProperty("QuoteStatus"),"QuoteStatus",parseInt(RowCount)+1);
  
  SeS('QuoteExecutionResults').SetCell(Global.GetProperty('QuoteNumber'), "QuoteNumber",parseInt(RowCount)+1);
  
  SeS('QuoteExecutionResults').SetCell(Tester.GetTestStatus()==0?"Failed":"Passed","TestStatus",parseInt(RowCount)+1);
  
  SeS('QuoteExecutionResults').SetCell(new Date(),"Timestamp",parseInt(RowCount)+1);
  
  SeS('QuoteExecutionResults').DoSave();
}



function QuoteExecution()
{
  data();
  
  if(Spreadsheet.GetCell('TestExecutionFlag',CurrentRow)!=="N")
  {
  Tester.BeginTest(Global.GetProperty('TestCase'));
  CreateNewQuote();
  QuoteCustomer();
  SelectQuoteProgram();
  PreliminaryQuoteDetails();
  AddAssetDetails();
  NavigateNextQuote();
  SaveQuote();
  QuotePricing();
  AcceptQuote();
  QuoteExecutionResults();
  Tester.EndTest();
  }
  
  

}

function SelectDropdown(/**string*/ locator,/**string*/ itemText)
{
   locator.DoClick();
   var objId = locator._DoDOMGetAttribute("id");
   objId=objId.replace("_label","");
   
   if(objId)
   {
     Navigator.ExecJS('return arguments[0].click();',Navigator.Find('//ul[@id="'+objId+'_items"]//li[@data-label="'+itemText+'"]'));
   }
   else
   {
     Tester.Assert('Error selecting option', false)
   }
   

}

function waitForAjaxSpinner()
{
  var waitTotal=0;
  var loader = SeSFindObj('AjaxSpinner');
  var display=false;
 
  do
  {
    if(SeSFindObj('AjaxSpinner'))
    {
      display=false;
      Global.DoSleep(2500)
      waitTotal=waitTotal+10000;
    }
    else
    {
      display=true;
    }
  }
  while(display!=true);

}

function waitForPageLoad()
{
  var waitTotal=0;
  var loader = SeSFindObj('PageLoad');
  var display=false;
 
  do
  {
    if(SeSFindObj('PageLoad'))
    {
      display=false;
      Global.DoSleep(4500)
      waitTotal=waitTotal+5000;
    }
    else
    {
      display=true;
    }
  }
  while(display!=true);
}

function addRelationships()
{
     var lastRow=(CurrentRow+counter)-1;
     
     for(relDetails=CurrentRow;relDetails<=lastRow;relDetails++)
     {
       if(Spreadsheet.GetCell('PartyRole',relDetails)!=="")
       {
           SeS('CreateRelationship').DoEnsureVisible();
           Navigator.ExecJS('return arguments[0].click();',SeS('CreateRelationship'));
           waitForPageLoad();
           Navigator.ExecJS('return arguments[0].click();',SeS('EditEntityRoles'));
           Global.DoWaitFor('EntityRoleDone',1200)
           Navigator.ExecJS('return arguments[0].click();',SeS('PartyRole',{PartyRole:Spreadsheet.GetCell('PartyRole',relDetails)}));
           Global.DoSleep(500);
           Navigator.ExecJS('return arguments[0].click();',SeS('SelectPartyRole'));
           Global.DoSleep(500);
           Navigator.ExecJS('return arguments[0].click();',SeS('EntityRoleDone'));
           
           SeS('Next').DoClick();
           
           SeS('Advanced_Search').DoClick();
           Global.DoWaitFor('CustomerNumberAdvancedSearch',150);
           SeS('CustomerNumberAdvancedSearch').DoClick();
           SeS('CustomerNumberAdvancedSearch').DoSetText(Spreadsheet.GetCell('EntityNumber',CurrentRow));
           SeS('AdvancedSearchButton').DoClick();
           SeS('Select').DoClick();
       
       }
     }
     
     var rows = SeS('RelationshipTable').DoDOMQueryXPath('./tr');
     for(rowCount=0;rowCount<rows.length;rowCount++)
     {
       var PartyRole = SeS('RelatedPartyRoles',{RelatedPartyNumber:rowCount}).GetText();
       Tester.Message('Party role is'+PartyRole);
       if(PartyRole=="Personal Guarantor")
       {
         var CreditAuthorization = SeS('CreditAuthorization',{RelatedPartyNumber:rowCount});
         SelectDropdown(CreditAuthorization,'Yes');
       }
     
     }

}

function CreateNewEntity()
{
  SheetName='EntityDetails';
  data();
  
  if(Spreadsheet.GetCell('EntityDetailsExecutionFlag',CurrentRow)=="Y")
  {
  
  Navigator.ExecJS('return arguments[0].click();',SeS('CreateCustomerQuote'));
   
  waitForPageLoad();
  
  var FederalTaxID = Math.floor((Math.random()+Math.floor(Math.random()*9)+1)*Math.pow(10,8));
  var LegalPhone = Math.floor(Math.random()*9000000000)+1000000000;
  var BusinessPhone = Math.floor(Math.random()*9000000000)+1000000000;
  var Mobile = Math.floor(Math.random()*9000000000)+1000000000;
    
  Global.DoWaitFor('LegalName',1500);

  //LegalName

  Navigator.ExecJS('return arguments[0].focus();',SeS('LegalName'));
  SeS('LegalName').DoClick();
  SeS('LegalName').DoSetText(Spreadsheet.GetCell('LegalName',CurrentRow));
   
  //DBAName
  Navigator.ExecJS('return arguments[0].focus();',SeS('DBAName'));
  SeS('DBAName').DoClick();
  SeS('DBAName').DoSetText(Spreadsheet.GetCell('LegalName',CurrentRow));
  
    
  //LegalEntityType
  
  var LegalEntityType = SeS('LegalEntityType');
  SelectDropdown(LegalEntityType,Spreadsheet.GetCell('LegalEntityType',CurrentRow))
  
  //NAICS 
  Navigator.ExecJS('return arguments[0].focus();',SeS('NAICSSearch'));
  Global.DoSleep(2500);
  Navigator.ExecJS('return arguments[0].click();',SeS('NAICSSearch'));
  waitForPageLoad();
  Global.DoWaitFor('Advanced_Search',1000)
  Navigator.ExecJS('return arguments[0].focus();',SeS('Advanced_Search'));
  Navigator.ExecJS('return arguments[0].click();',SeS('Advanced_Search'));
  SeS('NAICSCode').DoSetText(Spreadsheet.GetCell('NAICS',CurrentRow));
  
  SeS('AdvancedSearchButton').DoClick();
       
  Global.DoWaitFor('Select',1000,500);
  SeS('Select').DoClick();
  
  //FederalTaxID
  SeS('FederalTaxID').DoClick();
  Global.DoSleep(2000);
  SeS('FederalTaxID').DoSendKeys(FederalTaxID);
  Global.DoSleep(2000);
  waitForAjaxSpinner();
  
  
  //PhoneNumber
  SeS('PhoneNumber').DoClick();
  Global.DoSleep(2000)
  SeS('PhoneNumber').DoSendKeys(LegalPhone);
  Global.DoSleep(2000)
  waitForAjaxSpinner();
  
  //PhoneVerified
  var PhoneVerified = SeS('PhoneVerified');
  SelectDropdown(PhoneVerified,Spreadsheet.GetCell('PhoneVerified',CurrentRow));
  waitForAjaxSpinner();
  
  SeS('SaveEntityFlow').DoClick();  
  waitForPageLoad();
  
  //EsignConsent
  
  var ESignConsent = SeS('EsignConsent');
  SelectDropdown(ESignConsent,Spreadsheet.GetCell('ESignConsent',CurrentRow));
  
  //Jurisdiction State
  var JurisdictionState = SeS('StateIncorporated');
  SelectDropdown(JurisdictionState,Spreadsheet.GetCell('OrganizedUnderState',CurrentRow));
  
  //Nature Of Business
  var BusinessNature = SeS('NatureOfBusiness');
  SelectDropdown(BusinessNature,Spreadsheet.GetCell('NatureOfBusiness',CurrentRow));
  waitForAjaxSpinner();
  
  
  Global.DoSleep(1500);
  
  var lastRow=(CurrentRow+counter)-1;
  
   for(entityContactDetails=CurrentRow;entityContactDetails<=lastRow;entityContactDetails++)
     {
       if(Spreadsheet.GetCell('AddressNumber',entityContactDetails)!=="")
       {
       var addressNum= parseInt(Spreadsheet.GetCell('AddressNumber',entityContactDetails))-1;  
       SeS('AddAddress').DoClick();
       Global.DoWaitFor('Address',2500,500);
       
       //State
       var AddressState = SeS('State',{AddressNumber:addressNum});
       SelectDropdown(AddressState,Spreadsheet.GetCell('State',entityContactDetails));
       
       //City
       SeS('City',{AddressNumber:addressNum}).DoClick();
       SeS('City',{AddressNumber:addressNum}).DoSetText(Spreadsheet.GetCell('City',entityContactDetails));
       
       //ZipCode
       SeS('PostalCode',{AddressNumber:addressNum}).DoClick();
       SeS('PostalCode',{AddressNumber:addressNum}).DoSetText(Spreadsheet.GetCell('ZipCode',entityContactDetails));
       
       //Address
       SeS('Address',{AddressNumber:addressNum}).DoClick();
       SeS('Address',{AddressNumber:addressNum}).DoSetText(Spreadsheet.GetCell('Address',entityContactDetails));
       
       //Submit
    //   SeS('AddressSubmit').DoClick();
    //   waitForPageLoad();
      
       SeS('CustomerAddressDone',{AddressNumber:addressNum}).DoClick();
       }
       if(Spreadsheet.GetCell('ContactDetailsNumber',entityContactDetails)!=="")
       {
          var contactDetailsNum= parseInt(Spreadsheet.GetCell('ContactDetailsNumber',entityContactDetails))-1;  
          SeS('CreateContactDetails').DoClick();
          waitForPageLoad();
          
          var Title=SeS('CustomerContactTitle',{CustomerContact:contactDetailsNum});
          SelectDropdown(Title,Spreadsheet.GetCell('Title',entityContactDetails));
          
          SeS('CustomerFirstName',{CustomerContact:contactDetailsNum}).DoClick();
          SeS('CustomerFirstName',{CustomerContact:contactDetailsNum}).DoSetText(Spreadsheet.GetCell('FirstName',entityContactDetails));
          
          SeS('CustomerLastName',{CustomerContact:contactDetailsNum}).DoClick();
          SeS('CustomerLastName',{CustomerContact:contactDetailsNum}).DoSetText(Spreadsheet.GetCell('LastName',entityContactDetails));
          
          SeS('CustomerBusinessPhone',{CustomerContact:contactDetailsNum}).DoClick();
          SeS('CustomerBusinessPhone',{CustomerContact:contactDetailsNum}).DoSendKeys(BusinessPhone);
          
          SeS('CustomerMobilePhone',{CustomerContact:contactDetailsNum}).DoClick();
          SeS('CustomerMobilePhone',{CustomerContact:contactDetailsNum}).DoSendKeys(Mobile);
          
          SeS('CustomerEmail',{CustomerContact:contactDetailsNum}).DoClick();
          SeS('CustomerEmail',{CustomerContact:contactDetailsNum}).DoSetText(Spreadsheet.GetCell('Email',entityContactDetails));
          
          SeS('CustomerContactDone',{CustomerContact:contactDetailsNum}).DoEnsureVisible();
          SeS('CustomerContactDone',{CustomerContact:contactDetailsNum}).DoClick();
         }
       else
       {
         continue;
       }
     }
     
     SeS('Save&Close').DoClick();
     
  }
  
  
  
  if(Global.GetProperty('CreateModule')=="Quote")
  {
    SheetName='Quotes';
    data();
  }
  else if(Global.GetProperty('CreateModule')=="Application")
  {
    SheetName='Application';
    data();
  }

}

function PropertiesToJSON(/**string*/propPath, /**string*/jsonPath)
{
	var str = File.Read(propPath);
	
	str = str.replace(/\\\n/, "");
	
	var parts = str.split("\n");
	var obj = {};
	
	for(var i=0;i<parts.length;i++)
	{
		var line = parts[i];
	
		if( /(\#|\!)/.test(line.replace(/\s/g, "").slice(0, 1)) )
		{
			
		} else {
			var colonifiedLine = line.replace(/(\=)/, ":")
			var key = colonifiedLine.substring(0, colonifiedLine.indexOf(":"));
			key = Global.DoTrim(key);
			var value = colonifiedLine.substring(colonifiedLine.indexOf(":") + 1);
			value = Global.DoTrim(value);
			if(key)
			{
				obj[key] = value
			}
		}
	}
	
	if( jsonPath )
	{
		File.Write(jsonPath, JSON.stringify(obj, null, '\t') );
	}
	return obj;
}
	
