function Test()
{
	Global.DoInvokeTest('./GradeQuotes/GradeQuotes.sstest');
}
