var saved_script_objects={
	"username": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "username",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@name='username' and @id='username']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/login.seam"
	},
	"password": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "password",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@name='password' and @id='password']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/login.seam"
	},
	"Sign_In": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "Sign In",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@name='signin' and @id='signin']/span[2]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/login.seam"
	},
	"Quotes": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Quotes",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@href='/search/quote/main/results.seam']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/humanTask/main/results.seam?canvasType=search&pageId=20&cid=1455"
	},
	"Create": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Create",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id='entityForm:results_table:results_createAction']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/quote/main/results.seam?canvasType=search&pageId=21&cid=1458"
	},
	"CreateAsset": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Create",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id='entityForm:quote_pricingOption_assets_table:quickAdd']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=23&cid=1459"
	},
	"AssetCategory": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Please Select ...",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://label[@id='entityForm:quote_pricingOption_assets_table:{AssetNumber}:asset_assetCategory_1:input_label']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=23&cid=1459",
		"AssetNumber": ""
	},
	"AssetType": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Please Select ...",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://label[@id='entityForm:quote_pricingOption_assets_table:{AssetNumber}:asset_assetType_1:input_label']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=23&cid=1459",
		"AssetNumber": ""
	},
	"Quantity": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Quantity",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@name='entityForm:quote_pricingOption_assets_table:{AssetNumber}:asset_quantity_1:input' and @id='entityForm:quote_pricingOption_assets_table:{AssetNumber}:asset_quantity_1:input']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=23&cid=1459",
		"AssetNumber": ""
	},
	"UnitCost": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "entityForm:quote_pricingOption_assets_table:{AssetNumber}:asset_unitCost_1:input:amount_input",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@name='entityForm:quote_pricingOption_assets_table:{AssetNumber}:asset_unitCost_1:input:amount_input']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=23&cid=1459",
		"AssetNumber": ""
	},
	"SearchAssetVendor": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Search",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://a[@id='entityForm:quote_pricingOption_assets_table:{AssetNumber}:asset_vendor:asset_vendor_search']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=23&cid=1459",
		"AssetNumber": ""
	},
	"Filter_by_Customer_Name": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Filter by Customer Name",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@name='entityForm:results_table:vendor_customer_customerName_col:filter' and @id='entityForm:results_table:vendor_customer_customerName_col:filter']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/vendor/sns_one/results.seam?pageId=24&cid=1459"
	},
	"Select": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Select",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[contains(@id,'entityForm:results_table:0')]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/vendor/sns_one/results.seam?pageId=24&cid=1459"
	},
	"AssetDone": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "Done",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://button[@name='entityForm:quote_pricingOption_assets_table:{AssetNumber}:quote_pricingOption_assets_doneBtn' and @id='entityForm:quote_pricingOption_assets_table:{AssetNumber}:quote_pricingOption_assets_doneBtn']/span[1]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?canvasType=crud&pageId=23&cid=1459",
		"AssetNumber": ""
	},
	"Next": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "Next",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@name='entityForm:nextEntityBtn' and @id='entityForm:nextEntityBtn']/span[1]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?canvasType=crud&pageId=23&cid=1459"
	},
	"ProfileLink": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n                                                    \n                            \n                            Deeksha ...",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "LI",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//li[@class='profile-item']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/humanTask/main/results.seam?canvasType=search&pageId=512&cid=11538"
	},
	"LogoutLink": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n                                    \n                                    Sign Out",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "\n                                    Sign Out",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@href=\"/logout\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/humanTask/main/results.seam?canvasType=search&pageId=512&cid=11538"
	},
	"PageLoad": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "image",
		"object_name": "PageLoad",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//img[@src='/images/loading_grey.gif']/parent::div/parent::div[contains(@aria-hidden,'false')]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/humanTask/main/results.seam?canvasType=search&pageId=512&cid=11538"
	},
	"GradeTestData": {
		"locations": [
			{
				"locator_name": "Spreadsheet",
				"location": {
					"path": "param:path"
				}
			}
		],
		"window_name": "Spreadsheets",
		"version": 0,
		"ignore_object_name": true,
		"object_type": "Spreadsheet",
		"object_flavor": "Table",
		"object_library": "Spreadsheet",
		"path": "%WORKDIR%\\GradeTestData.xlsx"
	},
	"Advanced_Search": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n              \t    \n                                ",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Advanced Search",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id='entityForm:results_table:advSearchAction']/i",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/vendor/sns_one/results.seam?pageId=75&cid=1980"
	},
	"AdvancedSearchButton": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Search",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:searchAction",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@id='entityForm:searchAction']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/vendor/sns_one/results.seam?pageId=75&cid=1980"
	},
	"Vendor_Number": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Vendor Number",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id=\"entityForm:vendor_vendorNumber:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/vendor/sns_one/results.seam?pageId=75&cid=1980"
	},
	"ErrorMessages": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Vendor Number",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//div[@id='error_messages']/div/ul",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/vendor/sns_one/results.seam?pageId=75&cid=1980"
	},
	"FinanceProductType": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "$1 Buyout Lease",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id=\"entityForm:quote_pricingOption_financialProductType:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=8&cid=79"
	},
	"Term": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Term (months)*",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id=\"entityForm:quote_pricingOption_structure_term:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=8&cid=79"
	},
	"RequestedAmount": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "entityForm:quote_pricingOption_structure_requestedAmount:input:amount_input",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id=\"entityForm:quote_pricingOption_structure_requestedAmount:input:amount_input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=8&cid=79"
	},
	"CustomerSearch": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n         ",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Search",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id=\"entityForm:quote_customer:quote_customer_search\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=17&cid=212"
	},
	"ProgramSearch": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n         ",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Search",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id=\"entityForm:quote_program:quote_program_search\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=17&cid=212"
	},
	"SaveQuote": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Save",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:saveFlowBtn",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@id='entityForm:saveFlowBtn']/span",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=21&cid=212"
	},
	"QuotePricing": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Price Quote",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:Quote_Pricing",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@id='entityForm:Quote_Pricing']/span",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/edit.seam?canvasType=crud&pageId=22&eid=25365624&cid=324"
	},
	"GenerateProposal": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Generate Proposal",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:Generate_Proposal",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@id='entityForm:Generate_Proposal']/span",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/edit.seam?canvasType=crud&pageId=22&eid=25365624&cid=324"
	},
	"More": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n\t\t",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "More",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[contains(@title,'More')]/i",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/edit.seam?canvasType=crud&pageId=22&eid=25365624&cid=324"
	},
	"Accept": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Accept",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id='entityForm:tab_quote_tabGroup:quote_pricingOptions_table:0:quick_Accept']/span",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/edit.seam?canvasType=crud&pageId=22&eid=25365624&cid=324"
	},
	"FilterByProgramName": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Program NameAl-karim Program\n",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Program NameAl-karim Program",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id='entityForm:results_table:program_programName_col:filter']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/program/sns_one/results.seam?pageId=217&cid=3788"
	},
	"FilterByProgramStatus": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Program NameAl-karim Program\n",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Program NameAl-karim Program",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id='entityForm:results_table:program_wfStatus_col:filter']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/program/sns_one/results.seam?pageId=217&cid=3788"
	},
	"FilterByCustomerNumber": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Program NameAl-karim Program\n",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Program NameAl-karim Program",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id='entityForm:results_table:customer_customerNumber_1:filter']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/program/sns_one/results.seam?pageId=217&cid=3788"
	},
	"CustomerNumberAdvancedSearch": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Program NameAl-karim Program\n",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Program NameAl-karim Program",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id='entityForm:customer_customerNumber:input']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/program/sns_one/results.seam?pageId=217&cid=3788"
	},
	"ProgramNameAdvancedSearch": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Program NameAl-karim Program\n",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Program NameAl-karim Program",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id='entityForm:program_programName:input']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/program/sns_one/results.seam?pageId=217&cid=3788"
	},
	"ContinueSession": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Continue",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[contains(text(),'Continue')]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/pages/session-expire-conc-decision.seam"
	},
	"MultipleSessionsDetected.": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "Multiple sessions detected.",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//div[@id='error_content_header']//span[contains(text(),'Multiple sessions detected.')]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/pages/session-expire-conc-decision.seam"
	},
	"ApplicationsTab": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Quotes",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@href='/search/request/main/results.seam']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/humanTask/main/results.seam?canvasType=search&pageId=20&cid=1455"
	},
	"ApplicationNature": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Syndicated",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id=\"entityForm:request_applicationNature:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=7&cid=1464"
	},
	"ApplicationType": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Small Ticket",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Business Banking",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id=\"entityForm:request_requestType:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=7&cid=1464"
	},
	"PurchaseType": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Please Select ...",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id=\"entityForm:request_purchaseType:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=7&cid=1464"
	},
	"ApplicationFinanceProductType": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Please Select ...",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id='entityForm:request_facilityApp_pricingOption_financialProductType:input_label']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=7&cid=1464"
	},
	"ApplicationTerm": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Term (months)*",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id=\"entityForm:request_facilityApp_pricingOption_structure_term:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=10&cid=1464"
	},
	"ApplicationRequestedAmount": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "entityForm:request_facilityApp_pricingOption_structure_requestedAmount:input:amount_input",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id=\"entityForm:request_facilityApp_pricingOption_structure_requestedAmount:input:amount_input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=10&cid=1464"
	},
	"ApplicationDownPaymentPercent": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Down Payment Percent",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id=\"entityForm:request_facilityApp_pricingOption_advanceMonies_downPaymentPercent:input_input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=10&cid=1464"
	},
	"ApplicationDownPaymentAmount": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "entityForm:request_facilityApp_pricingOption_advanceMonies_downPaymentAmount:input:amount_input",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id=\"entityForm:request_facilityApp_pricingOption_advanceMonies_downPaymentAmount:input:amount_input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=10&cid=1464"
	},
	"CreateApplicationAsset": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n              \t    \n                                ",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Create",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id=\"entityForm:request_facilityApp_pricingOption_assets_table:quickAdd\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=10&cid=1464"
	},
	"ApplicationAssetCategory": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Please Select ...",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://label[@id='entityForm:request_facilityApp_pricingOption_assets_table:{AssetNumber}:asset_assetCategory_1:input_label']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=10&cid=1464",
		"AssetNumber": ""
	},
	"ApplicationAssetType": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Please Select ...",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://label[@id=\"entityForm:request_facilityApp_pricingOption_assets_table:{AssetNumber}:asset_assetType_1:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=10&cid=1464",
		"AssetNumber": ""
	},
	"ApplicationAssetQuantity": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Quantity",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@id=\"entityForm:request_facilityApp_pricingOption_assets_table:{AssetNumber}:asset_quantity_1:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=10&cid=1464",
		"AssetNumber": ""
	},
	"ApplicationAssetCost": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "entityForm:request_facilityApp_pricingOption_assets_table:0:asset_unitCost_1:input:amount_input",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@id=\"entityForm:request_facilityApp_pricingOption_assets_table:{AssetNumber}:asset_unitCost_1:input:amount_input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=10&cid=1464",
		"AssetNumber": ""
	},
	"ApplicationAssetVendor": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n         ",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Search",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://a[@id=\"entityForm:request_facilityApp_pricingOption_assets_table:{AssetNumber}:asset_vendor:asset_vendor_search\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=10&cid=1464",
		"AssetNumber": ""
	},
	"ApplicationAssetDone": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Done",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:request_facilityApp_pricingOption_assets_table:0:request_facilityApp_pricingOption_assets_doneBtn",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://button[@id=\"entityForm:request_facilityApp_pricingOption_assets_table:{AssetNumber}:request_facilityApp_pricingOption_assets_doneBtn\"]/span",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=10&cid=1464",
		"AssetNumber": ""
	},
	"NextNavigateApplication": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Next",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:nextEntityBtn",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@id=\"entityForm:nextEntityBtn\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=130&cid=3315"
	},
	"SaveApplication": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Save",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:saveFlowBtn",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@id=\"entityForm:saveFlowBtn\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=131&cid=3315"
	},
	"SubmitApplication": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Submit",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:Submit",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@id=\"entityForm:Submit\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=132&eid=25650588&cid=3338"
	},
	"ApplicationStatus": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "Pending - Sales Review",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//span[@id=\"entityForm:request_headers_table:0:head_wfStatus_value:output\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=182&eid=25651197&cid=3667"
	},
	"TaskHandlingIcon": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n\t\t",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "More",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[contains(@title,'More')]/i",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=182&eid=25651197&cid=3667"
	},
	"TaskSubHandlingIcon": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "Submit to Credit",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://a//span[contains(text(),'{TaskSubAction}')]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=182&eid=25651197&cid=3667",
		"TaskSubAction": ""
	},
	"ConfirmTaskDialog": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Submit",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:Submit",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[contains(@class,'confirmdialog-yes') and not(contains(@id,'pageOutConfirmDlg'))]/span[1]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=132&eid=25650588&cid=3338"
	},
	"ApplicationReviewTab": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Application Review",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@href=\"#entityForm:tab_creditRequest_tabGroup:tab_creditRequestReview_tab\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=195&eid=25652178&cid=4055"
	},
	"DuplicateApplicationsTab": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Duplicate Applications",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@href=\"#entityForm:tab_creditRequest_tabGroup:tab_Request_duplicateCustomer_tabGroup:tab_Request_duplicateApplication_tab\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=195&eid=25652178&cid=4055"
	},
	"VerificationOfDuplicates": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Clear",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@for=\"entityForm:tab_creditRequest_tabGroup:tab_Request_duplicateCustomer_tabGroup:request_duplicateApp_duplicateAppVerification:input:0\" and text()='Clear']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=195&eid=25652178&cid=4055"
	},
	"DuplicateApplicationComments": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Comments",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//textarea[@id=\"entityForm:tab_creditRequest_tabGroup:tab_Request_duplicateCustomer_tabGroup:request_duplicateApp_comments:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=195&eid=25652178&cid=4055"
	},
	"ApplicationSearchResults": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": " Application Search Results",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//span[@title=\" Application Search Results\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/request/main/results.seam?canvasType=search&pageId=1136&cid=5149"
	},
	"CreateRelationship": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n              \t    \n                                ",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Create",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id=\"entityForm:tab_creditRequest_tabGroup:Request_appRelationship_relatedParties_table:Request_appRelationship_relatedParties_createAction\"]/i",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=1374&eid=25893681&cid=8804"
	},
	"EditEntityRoles": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "I",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id=\"entityForm:relationshipParty_relatedRoles:input_edit\"]/span/i[@aria-hidden=\"true\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/relationshipParty/create.seam?pageId=1377&cid=8804"
	},
	"PartyRole": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Co-Lessee",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://li[@role=\"menuitem\" and @data-item-label='{PartyRole}']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/relationshipParty/create.seam?pageId=1377&cid=8804",
		"PartyRole": ""
	},
	"SelectPartyRole": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "Add",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@role=\"button\" and @type=\"button\" and @title=\"Add\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/relationshipParty/create.seam?pageId=1377&cid=8804"
	},
	"EntityRoleDone": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Done",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:relationshipParty_relatedRoles:pick_partyRole_relationshipParty_relatedRolesEntity_done",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@id=\"entityForm:relationshipParty_relatedRoles:pick_partyRole_relationshipParty_relatedRolesEntity_done\"]/span",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/relationshipParty/create.seam?pageId=1377&cid=8804"
	},
	"RelationshipTable": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Customer Number919153Customer Name\n\t\t\t\t\t\tSinclair & Co    \n\n\n\t\t\t\n\nTaxpayer ID Number\n\t\t\t\t\t\t**-***5641\n \n\t\t\t\n\nAddress\n\t\t\t...",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "entityForm:tab_creditRequest_tabGroup:Request_appRelationship_relatedParties_table_data",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//tbody[@id=\"entityForm:tab_creditRequest_tabGroup:Request_appRelationship_relatedParties_table_data\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=1681&eid=25917034&cid=10899"
	},
	"RelatedPartyRoles": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "Personal Guarantor",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://span[@id=\"entityForm:tab_creditRequest_tabGroup:Request_appRelationship_relatedParties_table:{RelatedPartyNumber}:relParties_assignedRoles_standarad:output\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=1681&eid=25917034&cid=10899",
		"RelatedPartyNumber": ""
	},
	"CreditAuthorization": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Please Select ...",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://label[@id=\"entityForm:tab_creditRequest_tabGroup:Request_appRelationship_relatedParties_table:{RelatedPartyNumber}:relParties_creditAuthorization:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=1681&eid=25917034&cid=10899",
		"RelatedPartyNumber": ""
	},
	"PBGradeTestDataSheet": {
		"locations": [
			{
				"locator_name": "Spreadsheet",
				"location": {
					"path": "param:path"
				}
			}
		],
		"window_name": "Spreadsheets",
		"version": 0,
		"ignore_object_name": true,
		"object_type": "Spreadsheet",
		"object_flavor": "Table",
		"object_library": "Spreadsheet",
		"path": "%WORKDIR%\\PBGradeTestData.xlsx"
	},
	"CreditAnalysisTab": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Credit Analysis",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@href=\"#entityForm:tab_creditRequest_tabGroup:tab_Request_creditAnalysis_tab\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=142&eid=25975614&cid=3240"
	},
	"ComplianceTab": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Compliance",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@href=\"#entityForm:tab_creditRequest_tabGroup:tab_Request_compliance_tabGroup:tab_Request_compliance_tab\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=142&eid=25975614&cid=3240"
	},
	"ComplianceEdit": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "I",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://a[@id='entityForm:tab_creditRequest_tabGroup:tab_Request_compliance_tabGroup:Request_compliances_table:{ComplianceRow}:Request_compliances_editAction']/i",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=142&eid=25975614&cid=3240",
		"ComplianceRow": ""
	},
	"ComplianceTable": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "HTMLObject",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//tbody[@id='entityForm:tab_creditRequest_tabGroup:tab_Request_compliance_tabGroup:Request_compliances_table_data']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=142&eid=25975614&cid=3240"
	},
	"AjaxSpinner": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "HTMLObject",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//i[contains(@class,'fa fa-circle-o-notch fa-spin ajax-loader')]/parent::div[contains(@style,'display: block')]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=142&eid=25975614&cid=3240"
	},
	"EditComplianceHeader": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "Edit Compliance",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//span[@title=\"Edit Compliance\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/compliance/edit.seam?pageId=276&cid=3996"
	},
	"OFACTab": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "OFAC",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@href=\"#entityForm:comDetails_ofac_tabGroup:comDetails_ofac_tab\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/compliance/edit.seam?pageId=276&cid=3996"
	},
	"OFACVerification": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Pending Review",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id=\"entityForm:comDetails_ofac_tabGroup:compliance_ofacComDetails_complianceHit_1:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/compliance/edit.seam?pageId=276&cid=3996"
	},
	"PEPTab": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "PEP's",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@href=\"#entityForm:comDetails_ofac_tabGroup:comDetails_pep_tab\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/compliance/edit.seam?pageId=276&cid=3996"
	},
	"PEPVerification": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Pending Review",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id='entityForm:comDetails_ofac_tabGroup:compliance_pepComDetails_complianceHit_1:input_label']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/compliance/edit.seam?pageId=276&cid=3996"
	},
	"BankruptcyTab": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "PEP's",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@href='#entityForm:comDetails_ofac_tabGroup:comDetails_bankruptcyComDetails_tab']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/compliance/edit.seam?pageId=276&cid=3996"
	},
	"BankruptcyVerification": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Pending Review",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id='entityForm:comDetails_ofac_tabGroup:compliance_bankruptcyComDetails_complianceHit_1:input_label']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/compliance/edit.seam?pageId=276&cid=3996"
	},
	"NegativeNewsTab": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "PEP's",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@href='#entityForm:comDetails_ofac_tabGroup:comDetails_criminalRecordComDetails_tab']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/compliance/edit.seam?pageId=276&cid=3996"
	},
	"NegativeNewsVerification": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Pending Review",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id='entityForm:comDetails_ofac_tabGroup:compliance_criminalRecordComDetails_complianceHit_1:input_label']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/compliance/edit.seam?pageId=276&cid=3996"
	},
	"SubPageSave": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Save",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:saveFlowBtn",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@id='entityForm:subpageEditSaveBtn']/span",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=21&cid=212"
	},
	"SubPageDone": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Save",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:saveFlowBtn",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@id='entityForm:subpageEditDoneBtn']/span",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=21&cid=212"
	},
	"SaveEntityFlow": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Save",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:saveFlowBtn",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[contains(@id,'entityForm:saveEntityBtn')]/span",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/create.seam?pageId=131&cid=3315"
	},
	"QuoteSearchResults": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": " Quote Search Results",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//span[@title=\" Quote Search Results\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/quote/main/results.seam?canvasType=search&pageId=984&cid=11449"
	},
	"SyndicationTab": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Syndication",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@href=\"#entityForm:tab_creditRequest_tabGroup:tab_Request_syndication_tab\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=1197&eid=26178823&cid=12558"
	},
	"SyndicatedStatus": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Please Select ...",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id=\"entityForm:tab_creditRequest_tabGroup:request_syndicatedStatus:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=1197&eid=26178823&cid=12558"
	},
	"ApplicationTab": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Application",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@href=\"#entityForm:tab_creditRequest_tabGroup:tab_creditRequest_tab\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=1197&eid=26178823&cid=12558"
	},
	"CustomerName": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Customer Name",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id=\"entityForm:quote_customerName:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=1525&cid=14155"
	},
	"CreateCustomerQuote": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "I",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id=\"entityForm:quote_customer:quote_customer_create\"]/i[@aria-hidden=\"true\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=1525&cid=14155"
	},
	"Non-Individual": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Non-Individual",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_customerType:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?pageId=1532&cid=14279"
	},
	"LegalName": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Legal Name*",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_legalName:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?pageId=1532&cid=14279"
	},
	"DBAName": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "DBA Name",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_dbaName:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?pageId=1532&cid=14279"
	},
	"LegalEntityType": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Please Select ...",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_legalEntityType:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?pageId=1532&cid=14279"
	},
	"FederalTaxID": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Federal Tax ID",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_federalTaxId:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?pageId=1532&cid=14279"
	},
	"PhoneNumber": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Phone Number",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_phoneNumber:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?pageId=1532&cid=14279"
	},
	"PhoneVerified": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Please Select ...",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_phoneVerified:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?pageId=1532&cid=14279"
	},
	"NAICSCode": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Code",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id=\"entityForm:naics_code:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/naics/sns_one/results.seam?pageId=1536&cid=14279"
	},
	"EsignConsent": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Yes",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_esignConsent_1:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=1532&cid=14279"
	},
	"StateIncorporated": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Please Select ...",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_stateIncorporated:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=1532&cid=14279"
	},
	"NatureOfBusiness": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Please Select ...",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_natureOfBusiness:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=1532&cid=14279"
	},
	"CreateContactDetails": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "I",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_contacts_table:quickAdd\"]/i[@aria-hidden=\"true\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=1532&cid=14279"
	},
	"CustomerContactTitle": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Please Select ...",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://label[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_contacts_table:{CustomerContact}:contact_title_1:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=1532&cid=14279",
		"CustomerContact": ""
	},
	"CustomerFirstName": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "First Name",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_contacts_table:{CustomerContact}:contact_firstName_1:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=1532&cid=14279",
		"CustomerContact": ""
	},
	"CustomerLastName": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Last Name",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_contacts_table:{CustomerContact}:contact_lastName_1:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=1532&cid=14279",
		"CustomerContact": ""
	},
	"CustomerBusinessPhone": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Business Phone",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_contacts_table:{CustomerContact}:contact_businessPhone_1:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=1532&cid=14279",
		"CustomerContact": ""
	},
	"CustomerMobilePhone": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Mobile Phone",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_contacts_table:{CustomerContact}:contact_mobilePhone_1:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=1532&cid=14279",
		"CustomerContact": ""
	},
	"CustomerEmail": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Email",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_contacts_table:{CustomerContact}:contact_email_1:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=1532&cid=14279",
		"CustomerContact": ""
	},
	"CustomerContactAddress": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Please Select ...",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://label[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_contacts_table:{CustomerContact}:contact_customerAddress:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=1532&cid=14279",
		"CustomerContact": ""
	},
	"CustomerContactDone": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "Done",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://button[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_contacts_table:{CustomerContact}:customer_contacts_doneBtn\"]/span",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=1532&cid=14279",
		"CustomerContact": ""
	},
	"AddAddress": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Create",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id='entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_addresses_table:quickAdd']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=511&cid=11418"
	},
	"State": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Please Select ...AlabamaAlaskaAmerican SamoaArizonaArkansasArmed Forces AmericasArmed Forces PacificCaliforniaColoradoCo...",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "State",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://label[@id='entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_addresses_table:{AddressNumber}:address_state_1:input_label']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=585&cid=12492",
		"AddressNumber": ""
	},
	"Address": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Address",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@name='entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_addresses_table:{AddressNumber}:address_address1_1:input']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=511&cid=11418",
		"AddressNumber": ""
	},
	"City": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "City/Town",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@name='entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_addresses_table:{AddressNumber}:address_city_1:input']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=511&cid=11418",
		"AddressNumber": ""
	},
	"PostalCode": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "ZIP/Postal Code",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@name='entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_addresses_table:{AddressNumber}:address_postalCode_1:input']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=511&cid=11418",
		"AddressNumber": ""
	},
	"AddressSubmit": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:tab_customerInformation_tabGroup:customer_addresses_table:Submit",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@name='entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_addresses_table:Submit']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=511&cid=11418"
	},
	"CustomerAddressDone": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Done",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "CustomerAddressDone",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://button[@id='entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_addresses_table:{AddressNumber}:customer_addresses_doneBtn']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam",
		"AddressNumber": ""
	},
	"NAICSSearch": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "I",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id=\"entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_naicsCodeInformation:customer_naicsCodeInformation_search\"]/i[@aria-hidden=\"true\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?pageId=1637&cid=15484"
	},
	"Save&Close": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "Save & Close",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@id=\"entityForm:saveAndCloseEntityBtn\"]/span",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=2060&cid=20664"
	},
	"QuoteStatus": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "New",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//span[@id=\"entityForm:quote_headers_table:0:head_wfStatus_value:output\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=5&cid=1597"
	},
	"QuoteNumber": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "812858",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//span[@id=\"entityForm:quote_headers_table:0:head_quoteNumber:output\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=5&cid=1597"
	},
	"QuotePricingOptionStatus": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "Priced",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//span[@id=\"entityForm:tab_quote_tabGroup:quote_pricingOptions_table:0:pricingOption_pricingOptionStatus:output\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/edit.seam?canvasType=crud&pageId=6&eid=26349621&cid=1650"
	},
	"ApplicationNumber": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "812858",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//span[@id=\"entityForm:request_headers_table:0:head_applicationNumber:output\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/request/edit.seam?canvasType=crud&pageId=10&eid=26350030&cid=1811"
	},
	"QuoteExecutionResults": {
		"locations": [
			{
				"locator_name": "Spreadsheet",
				"location": {
					"path": "param:path"
				}
			}
		],
		"window_name": "Spreadsheets",
		"version": 0,
		"ignore_object_name": true,
		"object_type": "Spreadsheet",
		"object_flavor": "Table",
		"object_library": "Spreadsheet",
		"path": "%WORKDIR%\\QuoteExecutionResults.xlsx"
	}
};