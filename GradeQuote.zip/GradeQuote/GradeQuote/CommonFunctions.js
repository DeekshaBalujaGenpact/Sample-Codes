// Select Dropdown by Value
function SelectDropdown(/**string*/ locator,/**string*/ itemText)
{
   locator.DoClick();
   var objId = locator._DoDOMGetAttribute("id");
   objId=objId.replace("_label","");
   
   if(objId)
   {
     Navigator.ExecJS('return arguments[0].click();',Navigator.Find('//ul[@id="'+objId+'_items"]//li[@data-label="'+itemText+'"]'));
   }
   else
   {
     Tester.Assert('Error selecting option', false)
   }
   

}

//Wait for ajax

function waitForAjaxSpinner()
{
  var waitTotal=0;
  var loader = SeSFindObj('AjaxSpinner');
  var display=false;
 
  do
  {
    if(SeSFindObj('AjaxSpinner'))
    {
      display=false;
      Global.DoSleep(2500)
      waitTotal=waitTotal+10000;
    }
    else
    {
      display=true;
    }
  }
  while(display!=true);

}

//wait for page load

function waitForPageLoad()
{
  var waitTotal=0;
  var loader = SeSFindObj('PageLoad');
  var display=false;
 
  do
  {
    if(SeSFindObj('PageLoad'))
    {
      display=false;
      Global.DoSleep(4500)
      waitTotal=waitTotal+5000;
    }
    else
    {
      display=true;
    }
  }
  while(display!=true);
}


function PropertiesToJSON(/**string*/propPath, /**string*/jsonPath)
{
	var str = File.Read(propPath);
	
	str = str.replace(/\\\n/, "");
	
	var parts = str.split("\n");
	var obj = {};
	
	for(var i=0;i<parts.length;i++)
	{
		var line = parts[i];
	
		if( /(\#|\!)/.test(line.replace(/\s/g, "").slice(0, 1)) )
		{
			
		} else {
			var colonifiedLine = line.replace(/(\=)/, ":")
			var key = colonifiedLine.substring(0, colonifiedLine.indexOf(":"));
			key = Global.DoTrim(key);
			var value = colonifiedLine.substring(colonifiedLine.indexOf(":") + 1);
			value = Global.DoTrim(value);
			if(key)
			{
				obj[key] = value
			}
		}
	}
	
	if( jsonPath )
	{
		File.Write(jsonPath, JSON.stringify(obj, null, '\t') );
	}
	return obj;
}



