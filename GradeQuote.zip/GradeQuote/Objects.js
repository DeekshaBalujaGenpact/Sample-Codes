var saved_script_objects={
	"username": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "username",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@name='username' and @id='username']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/login.seam"
	},
	"password": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "password",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@name='password' and @id='password']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/login.seam"
	},
	"Sign_In": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "Sign In",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@name='signin' and @id='signin']/span[2]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/login.seam"
	},
	"Quotes": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Quotes",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@href='/search/quote/main/results.seam']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/humanTask/main/results.seam?canvasType=search&pageId=20&cid=1455"
	},
	"Create": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Create",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id='entityForm:results_table:results_createAction']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/quote/main/results.seam?canvasType=search&pageId=21&cid=1458"
	},
	"CreateAsset": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Create",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id='entityForm:quote_pricingOption_assets_table:quickAdd']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=23&cid=1459"
	},
	"AssetCategory": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Please Select ...",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://label[@id='entityForm:quote_pricingOption_assets_table:{AssetNumber}:asset_assetCategory_1:input_label']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=23&cid=1459",
		"AssetNumber": ""
	},
	"AssetType": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Please Select ...",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://label[@id='entityForm:quote_pricingOption_assets_table:{AssetNumber}:asset_assetType_1:input_label']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=23&cid=1459",
		"AssetNumber": ""
	},
	"Quantity": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Quantity",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@name='entityForm:quote_pricingOption_assets_table:{AssetNumber}:asset_quantity_1:input' and @id='entityForm:quote_pricingOption_assets_table:{AssetNumber}:asset_quantity_1:input']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=23&cid=1459",
		"AssetNumber": ""
	},
	"UnitCost": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "entityForm:quote_pricingOption_assets_table:{AssetNumber}:asset_unitCost_1:input:amount_input",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@name='entityForm:quote_pricingOption_assets_table:{AssetNumber}:asset_unitCost_1:input:amount_input']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=23&cid=1459",
		"AssetNumber": ""
	},
	"SearchAssetVendor": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Search",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://a[@id='entityForm:quote_pricingOption_assets_table:{AssetNumber}:asset_vendor:asset_vendor_search']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=23&cid=1459",
		"AssetNumber": ""
	},
	"Filter_by_Customer_Name": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Filter by Customer Name",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@name='entityForm:results_table:vendor_customer_customerName_col:filter' and @id='entityForm:results_table:vendor_customer_customerName_col:filter']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/vendor/sns_one/results.seam?pageId=24&cid=1459"
	},
	"Select": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Select",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[contains(@id,'entityForm:results_table:0')]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/vendor/sns_one/results.seam?pageId=24&cid=1459"
	},
	"AssetDone": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "Done",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://button[@name='entityForm:quote_pricingOption_assets_table:{AssetNumber}:quote_pricingOption_assets_doneBtn' and @id='entityForm:quote_pricingOption_assets_table:{AssetNumber}:quote_pricingOption_assets_doneBtn']/span[1]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?canvasType=crud&pageId=23&cid=1459",
		"AssetNumber": ""
	},
	"Next": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "Next",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@name='entityForm:nextEntityBtn' and @id='entityForm:nextEntityBtn']/span[1]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?canvasType=crud&pageId=23&cid=1459"
	},
	"ProfileLink": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n                                                    \n                            \n                            Deeksha ...",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "LI",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//li[@class='profile-item']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/humanTask/main/results.seam?canvasType=search&pageId=512&cid=11538"
	},
	"LogoutLink": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n                                    \n                                    Sign Out",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "\n                                    Sign Out",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@href=\"/logout\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/humanTask/main/results.seam?canvasType=search&pageId=512&cid=11538"
	},
	"PageLoad": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "image",
		"object_name": "PageLoad",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//img[contains(@src,'images/loading_grey.gif')]/parent::div/parent::div[contains(@aria-hidden,'false')]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/humanTask/main/results.seam?canvasType=search&pageId=512&cid=11538"
	},
	"GradeTestData": {
		"locations": [
			{
				"locator_name": "Spreadsheet",
				"location": {
					"path": "param:path"
				}
			}
		],
		"window_name": "Spreadsheets",
		"version": 0,
		"ignore_object_name": true,
		"object_type": "Spreadsheet",
		"object_flavor": "Table",
		"object_library": "Spreadsheet",
		"path": "%WORKDIR%\\GradeTestData.xlsx"
	},
	"Advanced_Search": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n              \t    \n                                ",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Advanced Search",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id='entityForm:results_table:advSearchAction']/i",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/vendor/sns_one/results.seam?pageId=75&cid=1980"
	},
	"AdvancedSearchButton": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Search",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:searchAction",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@id='entityForm:searchAction']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/vendor/sns_one/results.seam?pageId=75&cid=1980"
	},
	"Vendor_Number": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Vendor Number",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id=\"entityForm:vendor_vendorNumber:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/vendor/sns_one/results.seam?pageId=75&cid=1980"
	},
	"ErrorMessages": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "Vendor Number",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//div[@id='error_messages']/div/ul",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/vendor/sns_one/results.seam?pageId=75&cid=1980"
	},
	"FinanceProductType": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "$1 Buyout Lease",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//label[@id=\"entityForm:quote_pricingOption_financialProductType:input_label\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=8&cid=79"
	},
	"Term": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Term (months)*",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id=\"entityForm:quote_pricingOption_structure_term:input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=8&cid=79"
	},
	"RequestedAmount": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "entityForm:quote_pricingOption_structure_requestedAmount:input:amount_input",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id=\"entityForm:quote_pricingOption_structure_requestedAmount:input:amount_input\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=8&cid=79"
	},
	"CustomerSearch": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n         ",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Search",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id=\"entityForm:quote_customer:quote_customer_search\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=17&cid=212"
	},
	"ProgramSearch": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n         ",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Search",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id=\"entityForm:quote_program:quote_program_search\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=17&cid=212"
	},
	"SaveQuote": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Save",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:saveFlowBtn",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@id='entityForm:saveFlowBtn']/span",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/create.seam?pageId=21&cid=212"
	},
	"QuotePricing": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Price Quote",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:Quote_Pricing",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@id='entityForm:Quote_Pricing']/span",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/edit.seam?canvasType=crud&pageId=22&eid=25365624&cid=324"
	},
	"GenerateProposal": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Generate Proposal",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:Generate_Proposal",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@id='entityForm:Generate_Proposal']/span",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/edit.seam?canvasType=crud&pageId=22&eid=25365624&cid=324"
	},
	"More": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n\t\t",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "More",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id='entityForm:tab_quote_tabGroup:quote_pricingOptions_table:0:actions']/i",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/edit.seam?canvasType=crud&pageId=22&eid=25365624&cid=324"
	},
	"Accept": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "param:object_name",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Accept",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id='entityForm:tab_quote_tabGroup:quote_pricingOptions_table:0:quick_Accept']/span",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/quote/edit.seam?canvasType=crud&pageId=22&eid=25365624&cid=324"
	},
	"FilterByProgramName": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Program NameAl-karim Program\n",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Program NameAl-karim Program",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id='entityForm:results_table:program_programName_col:filter']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/program/sns_one/results.seam?pageId=217&cid=3788"
	},
	"FilterByCustomerNumber": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Program NameAl-karim Program\n",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Program NameAl-karim Program",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id='entityForm:results_table:customer_customerNumber_1:filter']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/program/sns_one/results.seam?pageId=217&cid=3788"
	},
	"CustomerNumberAdvancedSearch": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Program NameAl-karim Program\n",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Program NameAl-karim Program",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id='entityForm:customer_customerNumber:input']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/program/sns_one/results.seam?pageId=217&cid=3788"
	},
	"ProgramNameAdvancedSearch": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Program NameAl-karim Program\n",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Program NameAl-karim Program",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@id='entityForm:program_programName:input']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/program/sns_one/results.seam?pageId=217&cid=3788"
	}
};