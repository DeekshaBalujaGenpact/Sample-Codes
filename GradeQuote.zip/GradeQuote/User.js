


var FileName="";
var SheetName="";
var TestCase="";
var CurrentRow="";
var counter=0;


function setGlobalData(/**string*/ filename,/**string*/ sheetname,/**string*/ testcase)
{
   FileName=filename;
   SheetName=sheetname;
   TestCase=testcase;
   data();
}


function data()
{
   var success = Spreadsheet.DoAttach(FileName,SheetName);
   Tester.Assert('Open Spreadsheet', success);
   
   var rowCount = Spreadsheet.GetRowCount();
   var columnCount = Spreadsheet.GetColumnCount();
   counter=0;
   
   for(i=1;i<=rowCount;i++)
   {
        if(Spreadsheet.GetCell(0,i) == TestCase)
		{
		    counter=counter+1;
		    if(counter==1)
		    {
		      CurrentRow=i;
		    }
		    
		}
		else
		{ 
		  continue;
		}
   }
 }


function Login ()
{
   SeS('username').DoClick();
   SeS('username').DoSetText(Spreadsheet.GetCell('Username',CurrentRow));
   SeS('password').DoClick();
   SeS('password').DoSetText(Spreadsheet.GetCell('Password',CurrentRow));
   SeS('Sign_In').DoClick();
  
}

function CreateNewQuote()
{
   SeS('Quotes').DoClick();
   waitForPageLoad();
   Navigator.ExecJS('return arguments[0].click();',SeS('Create'));
}


function AddAssetDetails()
{
     
     
     var lastRow=(CurrentRow+counter)-1;
     
     for(assetDetails=CurrentRow;assetDetails<=lastRow;assetDetails++)
     {
       if(Spreadsheet.GetCell('AssetNumber',assetDetails)!=="")
       {
       var assetNum= parseInt(Spreadsheet.GetCell('AssetNumber',assetDetails))-1;  
       SeS('CreateAsset').DoClick();
       waitForPageLoad();
       
       //AssetCategory
       var AssetCategory = SeS('AssetCategory',{AssetNumber:assetNum});
       SelectDropdown(AssetCategory,Spreadsheet.GetCell('AssetCategory',assetDetails));
       
       Global.DoSleep(1000);
       
       //AssetType
       var AssetType = SeS('AssetType',{AssetNumber:assetNum});
       SelectDropdown(AssetType,Spreadsheet.GetCell('AssetType',assetDetails));
       
       //Quantity
       SeS('Quantity',{AssetNumber:assetNum}).DoClick();
       SeS('Quantity',{AssetNumber:assetNum}).DoSetText("");
       SeS('Quantity',{AssetNumber:assetNum}).DoClick();
       SeS('Quantity',{AssetNumber:assetNum}).DoSetText(Spreadsheet.GetCell('AssetQuantity',assetDetails));
       
       //UnitCost
       SeS('UnitCost',{AssetNumber:assetNum}).DoClick();
       SeS('UnitCost',{AssetNumber:assetNum}).DoSetText(Spreadsheet.GetCell('UnitCost',assetDetails));
       
       //SearchVendor
       SeS('SearchAssetVendor',{AssetNumber:assetNum}).DoClick();
       
       Global.DoWaitFor('Advanced_Search',500,100);
       SeS('Advanced_Search').DoClick();
       Global.DoWaitFor('Vendor_Number',1000,500);
       SeS('Vendor_Number').DoSetText(Spreadsheet.GetCell('AssetVendor',assetDetails))
	   Global.DoSleep(200)
       SeS('VendorSearch').DoClick();
       
       Global.DoWaitFor('Select',1000,500);
       SeS('Select').DoClick();
       
       //AssetDone
       SeS('AssetDone',{AssetNumber:assetNum}).DoEnsureVisible();
       SeS('AssetDone',{AssetNumber:assetNum}).DoClick();
       }
       else
       {
         continue;
       }
     }

  
}

function NavigateNext(/**string*/ ErrorMessageIdentifiers)
{
   SeS('Next').DoClick();
   if(ErrorMessageIdentifiers!=="")
   {
   Global.DoWaitFor('ErrorMessages',800);
   checkErrorMessages(ErrorMessageIdentifiers);
   }
}

function checkErrorMessages(/**string*/ ErrorMessageIdentifiers)
{
  var expectedErrors = [];
  var actualErrors = [];

  var jsonText = File.Read('ErrorMessages.json');
  var jsonErrorMessage = JSON.parse(jsonText);
  var errorKeys = ErrorMessageIdentifiers.split(',');
  

  for(var i=0;i<errorKeys.length;i++) 
  {
   var expectedErrorKey = errorKeys[i].replace(/^\s*/, "").replace(/\s*$/, "");
   expectedErrors.push(jsonErrorMessage.QCErrorMessages[expectedErrorKey])
   
  }
  
  var errorCount=0;
  if(SeSFindObj('ErrorMessages'))
  {
    errorCount=SeS('ErrorMessages').DoDOMChildrenCount();
    var errorlist=SeS('ErrorMessages').DoDOMQueryXPath('*');
    
    for(var i=0;i<errorlist.length;i++)
    {
      var error = errorlist[i];
      actualErrors.push(error.GetText())
    }

   actualErrors.sort();
   expectedErrors.sort();

   //Compare actual and expected error messages

   if(expectedErrors.length==actualErrors.length)
   {
     if(JSON.stringify(expectedErrors) === JSON.stringify(actualErrors))
     {
       Tester.Assert('Error messages displayed as expected',true)
     }
     else
     {
       Tester.Assert('Error messages not displayed as expected',comparison)
     }
   
   }
   
   
    
  }
  else
  {
    Tester.Assert("No error message present", false)
  }
}

function Logout()
{

  SeS('ProfileLink').DoClick();
  SeS('LogoutLink').DoClick();

}

function SelectDropdown(/**string*/ locator,/**string*/ itemText)
{
   locator.DoClick();
   var objId = locator._DoDOMGetAttribute("id");
   objId=objId.replace("_label","");
   
   if(objId)
   {
   Navigator.ExecJS('return arguments[0].click();',Navigator.Find('//ul[@id="'+objId+'_items"]//li[@data-label="'+itemText+'"]'));
   }
   else
   {
     Tester.Assert('Error selecting option', false)
   }

}

function waitForPageLoad()
{
  var waitTotal=0;
  var loader = SeSFindObj('PageLoad');
  var display=false;
  
  do
  {
    if(SeSFindObj('PageLoad'))
    {
      display=false;
      Global.DoSleep(3000)
      waitTotal=waitTotal+5000;
    }
    else
    {
      display=true;
    }
  }
  while(display!=true);



}
	
