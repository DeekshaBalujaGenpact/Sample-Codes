var saved_script_objects={
	"username": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "username",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@name='username' and @id='username']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/login.seam"
	},
	"password": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "password",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//input[@name='password' and @id='password']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/login.seam"
	},
	"Sign_In": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "Sign In",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@name='signin' and @id='signin']/span[2]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/login.seam"
	},
	"Entities": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Entities",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//li[@id='menuform:j_idt48']/a",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/humanTask/main/results.seam?canvasType=search&pageId=509&cid=11416"
	},
	"Create": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Create",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id='entityForm:results_table:results_createAction']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/customer/main/results.seam?canvasType=search&pageId=510&cid=11417"
	},
	"AddAddress": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "Create",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@id='entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_addresses_table:quickAdd']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=511&cid=11418"
	},
	"State": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Please Select ...AlabamaAlaskaAmerican SamoaArizonaArkansasArmed Forces AmericasArmed Forces PacificCaliforniaColoradoCo...",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Cell",
		"object_name": "State",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://label[@id='entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_addresses_table:{AddressNumber}:address_state_1:input_label']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=585&cid=12492",
		"AddressNumber": ""
	},
	"Address": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "Address",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@name='entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_addresses_table:{AddressNumber}:address_address1_1:input']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=511&cid=11418",
		"AddressNumber": ""
	},
	"City": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "City/Town",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@name='entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_addresses_table:{AddressNumber}:address_city_1:input']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=511&cid=11418",
		"AddressNumber": ""
	},
	"PostalCode": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Text",
		"object_name": "ZIP/Postal Code",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://input[@name='entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_addresses_table:{AddressNumber}:address_postalCode_1:input']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=511&cid=11418",
		"AddressNumber": ""
	},
	"AddressSubmit": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Chrome Legacy Window",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "entityForm:tab_customerInformation_tabGroup:customer_addresses_table:Submit",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//button[@name='entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_addresses_table:Submit']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam?canvasType=crud&pageId=511&cid=11418"
	},
	"ProfileLink": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n                                                    \n                            \n                            Deeksha ...",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Generic",
		"object_name": "LI",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//li[@class='profile-item']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/humanTask/main/results.seam?canvasType=search&pageId=512&cid=11538"
	},
	"LogoutLink": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "\n                                    \n                                    Sign Out",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Link",
		"object_name": "\n                                    Sign Out",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//a[@href=\"/logout\"]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/humanTask/main/results.seam?canvasType=search&pageId=512&cid=11538"
	},
	"PageLoad": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "image",
		"object_name": "PageLoad",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "//img[contains(@src,'images/loading_grey.gif')]/parent::div/parent::div[contains(@aria-hidden,'false')]",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/search/humanTask/main/results.seam?canvasType=search&pageId=512&cid=11538"
	},
	"CustomerAddressDone": {
		"locations": [
			{
				"locator_name": "HTML",
				"location": {
					"xpath": "param:xpath",
					"url": "param:url",
					"title": "param:title"
				}
			}
		],
		"window_class": "Chrome_WidgetWin_1",
		"object_text": "Done",
		"object_role": "ROLE_SYSTEM_WINDOW",
		"object_class": "Chrome_RenderWidgetHostHWND",
		"version": 0,
		"object_type": "HTMLObject",
		"object_flavor": "Button",
		"object_name": "CustomerAddressDone",
		"ignore_object_name": true,
		"object_library": "Chrome HTML",
		"window_name": "GRADE",
		"xpath": "param_vars://button[@id='entityForm:tab_customer_three_sixty_tabGroup:tab_customerInformation_tabGroup:customer_addresses_table:{AddressNumber}:customer_addresses_doneBtn']",
		"title": "GRADE",
		"url": "https://macquarie-qc.staging.gfincloud.com/crud/customer/create.seam",
		"AddressNumber": ""
	}
};