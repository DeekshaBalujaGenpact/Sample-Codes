function Login (/**string*/ username,/**string*/ password)
{
   SeS('username').DoClick();
   SeS('username').DoSetText(username);
   SeS('password').DoClick();
   SeS('password').DoSetText(password);
   SeS('Sign_In').DoClick();
}

function CreateNewEntity()
{
   SeS('Entities').DoClick();
   Navigator.ExecJS('return arguments[0].click();',SeS('Create'));
   

}


function AddAddressDetails(/**string*/ AddressNumber,/**string*/ Address,/**string*/ City,/**string*/ ZipCode,/**string*/ State)
{
     var addressNum= parseInt(AddressNumber)-1;  
     SeS('AddAddress').DoClick();
     Global.DoWaitFor('Address',2500,500);
     
     //State
     var AddressState = SeS('State',{AddressNumber:addressNum});
     SelectDropdown(AddressState,State);
     
     //City
     SeS('City',{AddressNumber:addressNum}).DoClick();
     SeS('City',{AddressNumber:addressNum}).DoSetText(City);
     
     //ZipCode
     SeS('PostalCode',{AddressNumber:addressNum}).DoClick();
     SeS('PostalCode',{AddressNumber:addressNum}).DoSetText(ZipCode);
     
     //Address
     SeS('Address',{AddressNumber:addressNum}).DoClick();
     SeS('Address',{AddressNumber:addressNum}).DoSetText(Address);
     
     //Submit
   //  SeS('AddressSubmit').DoClick();
   //  waitForPageLoad();
      
    
     SeS('CustomerAddressDone',{AddressNumber:addressNum}).DoClick();
     
     
     

}

function Logout()
{

  SeS('ProfileLink').DoClick();
  SeS('LogoutLink').DoClick();

}

function SelectDropdown(/**string*/ locator,/**string*/ itemText)
{
   locator.DoClick();
   var objId = locator._DoDOMGetAttribute("id");
   objId=objId.replace("_label","");
   
   if(objId)
   {
   Navigator.ExecJS('return arguments[0].click();',Navigator.Find('//ul[@id="'+objId+'_items"]//li[@data-label="'+itemText+'"]'));
   }
   else
   {
     Tester.Assert('Error selecting option', false)
   }

}

function waitForPageLoad()
{
  var waitTotal=0;
  var loader = SeSFindObj('PageLoad');
  var display=false;
  
  do
  {
    if(SeSFindObj('PageLoad'))
    {
      display=false;
      Global.DoSleep(3000)
      waitTotal=waitTotal+3000;
    }
    else
    {
      display=true;
    }
  }
  while(display!=true);



}
	
