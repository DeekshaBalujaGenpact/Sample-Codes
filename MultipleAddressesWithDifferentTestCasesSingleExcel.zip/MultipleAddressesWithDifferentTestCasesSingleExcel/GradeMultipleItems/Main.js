

function Test(params)
{

   RVL.DoPlayScript("Main.rvl.xlsx","RVL");

}

g_load_libraries=["%g_browserLibrary:Chrome HTML%"]
//g_load_libraries=["%g_browserLibrary:Internet Explorer HTML%"]



